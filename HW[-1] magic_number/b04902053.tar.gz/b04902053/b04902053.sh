make clean
make
make run
