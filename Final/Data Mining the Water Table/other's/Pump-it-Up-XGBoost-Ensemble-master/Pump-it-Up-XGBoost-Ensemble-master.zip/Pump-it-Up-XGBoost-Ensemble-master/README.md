# Pump-it-Up-XGBoost-Ensemble
Ensemble of XGBoost models to build a solution for DrivenData.com's Pump it Up: Data Mining the Water Table competion

Matt Brown                

email: matthew.brown.iowa@gmail.com

Location: Washington, DC

Website: www.DrivenData.org

Competition: Pump it Up: Data Mining the Water Table

Solution is 9th out of 2017 participants

Software Tools: XGBoost package in R

Brief Model Description: Ensemble of 11 XGBoost models with equal weight to each solution

Feature Selection
The original data set contained 40 variables. I reduced it down to 26 variables by removing variables
that were similar/duplicates of other variables.
